# Student-Management-System
Student Management System implemented in Java and MySQL.

# Features 
*	Dashboard 
*	User can login as multiple roles
*	View,edit,remove student
*	Student payment management
*	Student attendance management
*	Manage teachers
*	Manage subjects
*	Print reports 

# Used Tools:
* NetBeans 8.2
*	Mysql

# Some Interfaces
![st1.png](st1.png)
<br>
![st2.png](st2.png)
<br>
![st3.png](st3.png)
